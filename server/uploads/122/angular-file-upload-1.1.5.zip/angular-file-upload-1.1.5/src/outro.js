    return module;
}));